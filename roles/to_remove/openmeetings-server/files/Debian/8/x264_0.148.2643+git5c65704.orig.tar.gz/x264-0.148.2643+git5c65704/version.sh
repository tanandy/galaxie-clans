#!/bin/sh
# Script modified from upstream source for Debian packaging since packaging
# won't include .git repository.
echo '#define X264_VERSION " r2643 5c65704"'
echo '#define X264_POINTVER "0.148.2643 5c65704"'
